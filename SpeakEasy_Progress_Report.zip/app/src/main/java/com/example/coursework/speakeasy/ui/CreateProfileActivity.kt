package com.example.coursework.speakeasy.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.animation.AnimationUtils
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.coursework.speakeasy.R
import com.example.coursework.speakeasy.data.AppDatabase
import com.example.coursework.speakeasy.data.User
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class CreateProfileActivity : AppCompatActivity() {
    private val userDao by lazy { AppDatabase.getDatabase(this).userDao() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Check if user already has a REAL name (not guest)
        val sharedPrefs = getSharedPreferences("user_prefs", Context.MODE_PRIVATE)
        val userName = sharedPrefs.getString("user_name", null)
        val isGuest = sharedPrefs.getBoolean("is_guest", false)

        setContentView(R.layout.activity_create_profile)

        // If user is already logged in, show greeting and profile options
        if (userName != null && !isGuest) {
            showLoggedInUI(userName)
        } else {
            showLoginUI()
        }
    }

    private fun showLoggedInUI(userName: String) {
        // Show greeting text
        val tvGreeting = findViewById<TextView>(R.id.tvGreeting)
        tvGreeting.text = "Hi, $userName!"

        // Show profile button
        val btnProfile = findViewById<ImageButton>(R.id.btnProfile)
        btnProfile.visibility = View.VISIBLE
        btnProfile.setOnClickListener {
            showProfileDialog()
        }
    }

    private fun showLoginUI() {
        val etUsername = findViewById<TextInputEditText>(R.id.etUsername)
        val etPassword = findViewById<TextInputEditText>(R.id.etPassword)
        val btnLogin = findViewById<Button>(R.id.btnLogin)

        // Load animations
        val buttonPressAnimation = AnimationUtils.loadAnimation(this, R.anim.button_press)

        btnLogin.setOnClickListener { view ->
            view.startAnimation(buttonPressAnimation)

            val username = etUsername.text.toString().trim()
            val password = etPassword.text.toString().trim()

            if (username.isNotEmpty() && password.isNotEmpty()) {
                CoroutineScope(Dispatchers.IO).launch {
                    val existingUser = userDao.getUserByUsername(username)
                    if (existingUser != null) {
                        // Check if the password matches
                        if (existingUser.password == password) {
                            // Save user info in shared preferences
                            val sharedPrefs = getSharedPreferences("user_prefs", Context.MODE_PRIVATE)
                            with(sharedPrefs.edit()) {
                                putString("user_name", existingUser.username)
                                putBoolean("is_guest", false)
                                apply()
                            }

                            // Navigate to DashboardActivity
                            runOnUiThread {
                                Toast.makeText(this@CreateProfileActivity, "Login successful!", Toast.LENGTH_SHORT).show()
                                startActivity(Intent(this@CreateProfileActivity, DashboardActivity::class.java))
                                finish()
                            }
                        } else {
                            // Password is incorrect
                            runOnUiThread {
                                Toast.makeText(this@CreateProfileActivity, "Incorrect password. Please try again.", Toast.LENGTH_SHORT).show()
                            }
                        }
                    } else {
                        // User does not exist
                        runOnUiThread {
                            Toast.makeText(this@CreateProfileActivity, "Username does not exist. Please register.", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            } else {
                Toast.makeText(this, "Please fill in all fields.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun showProfileDialog() {
        // Show a dialog with options to change password or full name
        val options = arrayOf("Change Password", "Change Full Name")
        val builder = android.app.AlertDialog.Builder(this)
        builder.setTitle("Profile Options")
        builder.setItems(options) { _, which ->
            when (which) {
                0 -> showChangePasswordDialog()
                1 -> showChangeNameDialog()
            }
        }
        builder.show()
    }

    private fun showChangePasswordDialog() {
        val builder = android.app.AlertDialog.Builder(this)
        builder.setTitle("Change Password")

        val input = android.widget.EditText(this)
        input.hint = "Enter New Password"
        input.inputType = android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        builder.setView(input)

        builder.setPositiveButton("Save") { _, _ ->
            val newPassword = input.text.toString().trim()
            if (newPassword.isNotEmpty()) {
                CoroutineScope(Dispatchers.IO).launch {
                    val sharedPrefs = getSharedPreferences("user_prefs", Context.MODE_PRIVATE)
                    val username = sharedPrefs.getString("user_name", null)
                    if (username != null) {
                        val user = userDao.getUserByUsername(username)
                        if (user != null) {
                            userDao.updateUser(user.copy(password = newPassword))
                            runOnUiThread {
                                Toast.makeText(this@CreateProfileActivity, "Password updated successfully!", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }
            } else {
                Toast.makeText(this, "Password cannot be empty.", Toast.LENGTH_SHORT).show()
            }
        }

        builder.setNegativeButton("Cancel", null)
        builder.show()
    }

    private fun showChangeNameDialog() {
        val builder = android.app.AlertDialog.Builder(this)
        builder.setTitle("Change Full Name")

        val input = android.widget.EditText(this)
        input.hint = "Enter New Full Name"
        input.inputType = android.text.InputType.TYPE_TEXT_VARIATION_PERSON_NAME
        builder.setView(input)

        builder.setPositiveButton("Save") { _, _ ->
            val newName = input.text.toString().trim()
            if (newName.isNotEmpty()) {
                CoroutineScope(Dispatchers.IO).launch {
                    val sharedPrefs = getSharedPreferences("user_prefs", Context.MODE_PRIVATE)
                    val username = sharedPrefs.getString("user_name", null)
                    if (username != null) {
                        val user = userDao.getUserByUsername(username)
                        if (user != null) {
                            userDao.updateUser(user.copy(fullName = newName))
                            runOnUiThread {
                                Toast.makeText(this@CreateProfileActivity, "Full name updated successfully!", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }
            } else {
                Toast.makeText(this, "Full name cannot be empty.", Toast.LENGTH_SHORT).show()
            }
        }

        builder.setNegativeButton("Cancel", null)
        builder.show()
    }
}